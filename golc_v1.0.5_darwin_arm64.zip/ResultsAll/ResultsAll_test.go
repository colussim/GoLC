package main

import "testing"

func Test_startServer(t *testing.T) {
	type args struct {
		port int
	}
	tests := []struct {
		name string
		args args
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			startServer(tt.args.port)
		})
	}
}

func Test_formatCodeLines(t *testing.T) {
	type args struct {
		numLines float64
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := formatCodeLines(tt.args.numLines); got != tt.want {
				t.Errorf("formatCodeLines() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestLanguageData_FormatCodeLines(t *testing.T) {
	type fields struct {
		Language   string
		CodeLines  int
		Percentage float64
		CodeLinesF string
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			l := &LanguageData{
				Language:   tt.fields.Language,
				CodeLines:  tt.fields.CodeLines,
				Percentage: tt.fields.Percentage,
				CodeLinesF: tt.fields.CodeLinesF,
			}
			l.FormatCodeLines()
		})
	}
}

func Test_isPortOpen(t *testing.T) {
	type args struct {
		port int
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := isPortOpen(tt.args.port); got != tt.want {
				t.Errorf("isPortOpen() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_main(t *testing.T) {
	tests := []struct {
		name string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			main()
		})
	}
}
